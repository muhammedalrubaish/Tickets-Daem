// popup.js - Manifest V3 compliant script for Daem Plus popup
const iframe = document.getElementById('daem-iframe');

// الاستماع للرسائل القادمة من موقع Vercel لحفظ حالة الصلاحيات وكلمة المرور
window.addEventListener('message', (event) => {
  if (event.data && event.data.action === 'SET_ROLE') {
    if (event.data.role) {
      chrome.storage.local.set({ 
        daemRole: event.data.role,
        daemPassword: event.data.password || '' 
      });
    } else {
      chrome.storage.local.remove(['daemRole', 'daemPassword']);
    }
  }
});

// تحديث رابط الإطار ليشمل رقم الإصدار والصلاحية وكلمة المرور المخزنة
function updateIframeSrc() {
  try {
    chrome.storage.local.get(['daemRole', 'daemPassword'], (result) => {
      const role = (result && result.daemRole) ? result.daemRole : '';
      const pass = (result && result.daemPassword) ? result.daemPassword : '';
      const version = chrome.runtime.getManifest().version;
      
      const targetSrc = "https://tickets-daem.vercel.app/extension-popup?v=" + version + "&role=" + role + "&p=" + encodeURIComponent(pass);
      
      // منع التكرار اللانهائي للتحديث
      if (iframe && iframe.src !== targetSrc && iframe.src !== targetSrc + "/") {
        iframe.src = targetSrc;
      }
    });
  } catch (e) {
    console.error("Failed to read chrome storage/manifest:", e);
  }
}

// تشغيل التحديث عند الجاهزية
document.addEventListener('DOMContentLoaded', updateIframeSrc);
