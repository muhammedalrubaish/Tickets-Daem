// تحديث الأرقام في الواجهة بسلاسة v4
function updateUI(counts) {
    if (!counts) return;
    document.getElementById('count-new').textContent = counts.new || 0;
    document.getElementById('count-recent').textContent = counts.recent || 0;
    document.getElementById('count-old').textContent = counts.old || 0;
    document.getElementById('count-very-old').textContent = counts.veryOld || 0;
    document.getElementById('count-not-solved').textContent = counts.notSolved || 0;
    document.getElementById('count-unassigned').textContent = counts.unassigned || 0;
}

// حساب العدادات من قائمة التذاكر بطريقة موحدة ومطابقة للموقع
function calculateCounts(tickets) {
    let counts = { new: 0, recent: 0, old: 0, veryOld: 0, unassigned: 0, notSolved: 0 };
    if (!Array.isArray(tickets)) return counts;
    
    tickets.forEach(ticket => {
        const status = (ticket.solution || "").trim();

        if (status === 'بلاغ جديد') {
            counts.new++;
        } else if (status === 'بانتظار المستفيد') {
            counts.recent++;
        } else if (status === 'لدى الوزارة') {
            counts.veryOld++;
        } else if (status === 'مشكلة عامة') {
            counts.old++;
        } else if (status === 'لم يتم الحل') {
            counts.notSolved++;
        }

        // حساب التذاكر المتأخرة لأكثر من أسبوع
        const isNew = status === 'بلاغ جديد' || status === 'غير محدد' || status === '';
        if (isNew && ticket.date && ticket.date !== 'غير محدد') {
            try {
                const ticketDate = new Date(ticket.date);
                const oneWeekAgo = new Date();
                oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
                if (ticketDate < oneWeekAgo) {
                    counts.unassigned++;
                }
            } catch (e) {}
        }
    });
    return counts;
}

// 1. قراءة وعرض البيانات المخبأة فوراً لضمان السرعة والـ Fallback
chrome.storage.local.get(['daemCounts'], function(result) {
    if (result.daemCounts) {
        updateUI(result.daemCounts);
    }
    // 2. جلب البيانات الحية مباشرة من الـ API عبر الخلفية وتحديث العدادات
    fetchLiveCounts();
});

function fetchLiveCounts() {
    chrome.runtime.sendMessage({ action: "FETCH_TICKETS" }, (response) => {
        if (chrome.runtime.lastError) {
            return;
        }
        if (response && response.tickets) {
            const counts = calculateCounts(response.tickets);
            updateUI(counts);
            // تحديث التخزين المحلي للرجوع إليه لاحقاً
            chrome.storage.local.set({ daemCounts: counts });
        }
    });
}

// مراقبة التغييرات في التخزين لتحديث الواجهة لحظياً (إذا حدث تعديل بالخلفية)
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.daemCounts) {
        updateUI(changes.daemCounts.newValue);
    }
});
