// popup.js - Manifest V3 compliant script for Daem Plus popup
const iframe = document.getElementById('daem-iframe');

// الاستماع للرسائل القادمة من موقع Vercel لحفظ حالة الصلاحيات
window.addEventListener('message', (event) => {
  if (event.data && event.data.action === 'SET_ROLE') {
    if (event.data.role) {
      chrome.storage.local.set({ daemRole: event.data.role });
    } else {
      chrome.storage.local.remove(['daemRole']);
    }
  }
});

// تحديث رابط الإطار ليشمل رقم الإصدار والصلاحية المخزنة
function updateIframeSrc() {
  try {
    chrome.storage.local.get(['daemRole'], (result) => {
      const role = (result && result.daemRole) ? result.daemRole : '';
      const version = chrome.runtime.getManifest().version;
      const targetSrc = "https://tickets-daem.vercel.app/extension-popup?v=" + version + "&role=" + role;
      
      // منع التكرار اللانهائي للتحديث
      if (iframe && iframe.src !== targetSrc && iframe.src !== targetSrc + "/") {
        iframe.src = targetSrc;
      }
    });
  } catch (e) {
    console.error("Failed to read chrome storage/manifest:", e);
  }
}

// تشغيل التحديث عند الجاهزية
document.addEventListener('DOMContentLoaded', updateIframeSrc);
