// منطق تلوين خلية "رقم التذكرة" v22 - الاستقرار النهائي مع لوحة التحكم العائمة Premium
let websiteTickets = [];

// جلب البيانات عبر الخلفية لتجاوز CORS
async function syncFromWebsite() {
  try {
    if (!chrome.runtime || !chrome.runtime.id) return;
    chrome.runtime.sendMessage({ action: "FETCH_TICKETS" }, (response) => {
      if (chrome.runtime.lastError) {
        // تجاهل الخطأ إذا لم تكن الخلفية جاهزة بعد لمنع إشعارات الأخطاء في كروم
        return;
      }
      if (response && response.tickets) {
        const resData = response.tickets;
        websiteTickets = Array.isArray(resData) ? resData : (resData.tickets || []);
      }
    });
  } catch (e) {
    // تجاهل خطأ سياق الإضافة غير الصالحة عند إعادة تحميل الإضافة
  }
}

function highlightTickets() {
  try {
    if (!chrome.runtime || !chrome.runtime.id) return;
  } catch (e) {
    return;
  }
  const allRows = document.querySelectorAll('tr');
  if (allRows.length === 0) return;

  let currentCounts = { new: 0, recent: 0, old: 0, veryOld: 0, unassigned: 0, notSolved: 0 };
  let foundAny = false;

  allRows.forEach(row => {
    const cells = row.querySelectorAll('td');
    if (cells.length < 3) return;

    // العمود الأول يحتوي عادة على رقم التذكرة
    const targetCell = cells[0];
    const text = targetCell.innerText.trim();
    const idMatch = text.match(/IM\d{5,9}/);
    const ticketId = idMatch ? idMatch[0] : null;

    // تنظيف التلوين
    targetCell.classList.remove('daem-cell-new', 'daem-cell-old', 'daem-cell-very-old', 'daem-cell-recent', 'daem-cell-unassigned', 'daem-cell-not-solved');

    if (ticketId) {
      const myTicket = websiteTickets.find(t => {
          const n = String(t.number || "").trim();
          return n.includes(ticketId) || ticketId.includes(n);
      });

      if (myTicket) {
        foundAny = true;
        const status = (myTicket.solution || "").trim();

        // حساب ما إذا كانت التذكرة متأخرة لأكثر من أسبوع
        const isNew = status === 'بلاغ جديد' || status === 'غير محدد' || status === '';
        let isLate = false;
        if (isNew && myTicket.date && myTicket.date !== 'غير محدد') {
          try {
            const ticketDate = new Date(myTicket.date);
            const oneWeekAgo = new Date();
            oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
            if (ticketDate < oneWeekAgo) {
              isLate = true;
            }
          } catch (e) {}
        }

        if (isLate) {
          targetCell.classList.add('daem-cell-unassigned');
          currentCounts.unassigned++;
        } else if (status === 'بلاغ جديد') {
          targetCell.classList.add('daem-cell-new');
          currentCounts.new++;
        } else if (status === 'بانتظار المستفيد') {
          targetCell.classList.add('daem-cell-recent');
          currentCounts.recent++;
        } else if (status === 'لدى الوزارة') {
          targetCell.classList.add('daem-cell-very-old');
          currentCounts.veryOld++;
        } else if (status === 'مشكلة عامة') {
          targetCell.classList.add('daem-cell-old');
          currentCounts.old++;
        } else if (status === 'لم يتم الحل') {
          targetCell.classList.add('daem-cell-not-solved');
          currentCounts.notSolved++;
        }
      }
    }
  });

  // لا نحدث العداد إلا إذا وجدنا بلاغات ملونة فعلاً في هذا الإطار
  if (foundAny) {
    try {
      if (chrome.runtime && chrome.runtime.id) {
        chrome.storage.local.set({ daemCounts: currentCounts });
      }
    } catch (e) {
      // تجاهل خطأ سياق الإضافة غير الصالحة عند إعادة تحميل الإضافة
    }
  }
}

// ==========================================
// ميزات لوحة تحكم عائمة ذكية (🚀 داعم بلس Premium)
// ==========================================

function findJournalUpdatesElement() {
  // 1. البحث باستخدام التسمية "تحديثات دفتر اليومية"
  const labels = Array.from(document.querySelectorAll('label, span, td, div, label-form'));
  for (const label of labels) {
    const txt = (label.innerText || '').trim();
    if (txt === 'تحديثات دفتر اليومية:' || txt === 'تحديثات دفتر اليومية' || txt.includes('دفتر اليومية') || txt.includes('Journal Updates')) {
      let parent = label.parentElement;
      while (parent && parent !== document.body) {
        // البحث عن textarea أولاً داخل نفس الحاوية
        const textarea = parent.querySelector('textarea');
        if (textarea && (textarea.readOnly || textarea.disabled || textarea.value.includes('Asia/Riyadh'))) {
          return textarea;
        }
        // إذا لم يكن textarea، نبحث عن حاوية div أو pre تحتوي على نصوص التحديثات
        const scrollableDivs = Array.from(parent.querySelectorAll('div, pre, td'));
        for (const div of scrollableDivs) {
          const val = div.innerText || '';
          if (val.includes('Asia/Riyadh') || val.includes('--') || /\d{2}\/\d{2}/.test(val)) {
            return div;
          }
        }
        parent = parent.parentElement;
      }
    }
  }

  // 2. البحث العام عن أي عنصر يحتوي على علامات التحديثات التاريخية (مثل Asia/Riyadh أو Contractor)
  const candidates = Array.from(document.querySelectorAll('textarea, div, pre, td'));
  for (const el of candidates) {
    const val = el.tagName === 'TEXTAREA' ? (el.value || '') : (el.innerText || '');
    if (val.includes('Asia/Riyadh') || val.includes('Contractor') || (val.includes('--') && /\d{2}\/\d{2}/.test(val))) {
      // نضمن ألا يكون هذا هو حقل الكتابة النشط للمستخدم
      if (el.tagName === 'TEXTAREA') {
        if (el.readOnly || el.disabled) {
          return el;
        }
      } else {
        // تجنب الحاويات الضخمة مثل body أو html
        if (el.tagName !== 'BODY' && el.tagName !== 'HTML' && val.length < 5000) {
          return el;
        }
      }
    }
  }
  return null;
}

let lastFocusedElement = null;
document.addEventListener('focusin', (e) => {
  const el = e.target;
  if (el && (
    el.tagName === 'TEXTAREA' || 
    (el.tagName === 'INPUT' && ['text', 'search', 'url', 'tel', 'email'].includes(el.type)) || 
    el.contentEditable === 'true' || 
    el.getAttribute('contenteditable') === 'true'
  )) {
    lastFocusedElement = el;
  }
});

function getEditableValue(el) {
  if (!el) return "";
  if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
    return el.value || "";
  }
  return el.innerText || "";
}

function setEditableValue(el, val) {
  if (!el) return;
  if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
    el.value = val;
  } else {
    el.innerText = val;
  }
}

function findActiveInput() {
  // 1. استخدام آخر حقل تم التركيز عليه من قبل المستخدم
  if (lastFocusedElement && document.body.contains(lastFocusedElement)) {
    return lastFocusedElement;
  }

  // 2. البحث عن أي حقل textarea نشط ومرئي ومفتوح للكتابة
  const textareas = Array.from(document.querySelectorAll('textarea'));
  const editableTextareas = textareas.filter(ta => !ta.readOnly && !ta.disabled && ta.style.display !== 'none');
  if (editableTextareas.length > 0) {
    for (const ta of editableTextareas) {
      const name = (ta.name || '').toLowerCase();
      const id = (ta.id || '').toLowerCase();
      if (name.includes('update') || name.includes('resolution') || name.includes('sol') || id.includes('update') || id.includes('resolution') || name.includes('desc') || id.includes('desc')) {
        return ta;
      }
    }
    return editableTextareas[0];
  }

  // 3. البحث في عناصر contenteditable
  const contentEditables = Array.from(document.querySelectorAll('[contenteditable="true"]'));
  if (contentEditables.length > 0) {
    return contentEditables[0];
  }

  // 4. البحث في حقول الإدخال النصية (input) المفتوحة للكتابة
  const inputs = Array.from(document.querySelectorAll('input[type="text"]'));
  const editableInputs = inputs.filter(inp => !inp.readOnly && !inp.disabled && inp.style.display !== 'none');
  if (editableInputs.length > 0) {
    return editableInputs[0];
  }

  // 5. البحث داخل أي iframe في الصفحة
  const iframes = Array.from(document.querySelectorAll('iframe'));
  for (const iframe of iframes) {
    try {
      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      if (iframeDoc) {
        const subTextareas = Array.from(iframeDoc.querySelectorAll('textarea'));
        const subEditable = subTextareas.filter(ta => !ta.readOnly && !ta.disabled && ta.style.display !== 'none');
        if (subEditable.length > 0) return subEditable[0];

        const subEditables = Array.from(iframeDoc.querySelectorAll('[contenteditable="true"]'));
        if (subEditables.length > 0) return subEditables[0];

        const subInputs = Array.from(iframeDoc.querySelectorAll('input[type="text"]'));
        const subEditableInputs = subInputs.filter(inp => !inp.readOnly && !inp.disabled && inp.style.display !== 'none');
        if (subEditableInputs.length > 0) return subEditableInputs[0];
      }
    } catch (e) {
      // قد يفشل بسبب سياسة المنشأ المشترك (cross-origin)
    }
  }

  return null;
}


function findAssigneeInput() {
  const labels = Array.from(document.querySelectorAll('label, span, td, div'));
  for (const label of labels) {
    const txt = (label.innerText || '').trim();
    if (txt === 'المستقبل' || txt === 'المستقبل:' || txt === 'Assignee' || txt.includes('Assignee')) {
      let parent = label.parentElement;
      while (parent && parent !== document.body) {
        const input = parent.querySelector('input[type="text"], select');
        if (input) return input;
        parent = parent.parentElement;
      }
    }
  }
  
  let el = document.querySelector('input[name*="assignee"], input[id*="assignee"], input[name*="receiver"], input[id*="receiver"]');
  if (el) return el;
  return null;
}

function extractLatestUpdate(fullText) {
  if (!fullText) return '';
  const lines = fullText.split('\n').map(l => l.trim()).filter(Boolean);
  let latestLines = [];
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    // تحديد ما إذا كان السطر يمثل ترويسة/بيانات وصفية (اسم الموظف، التوقيت، المنطقة الزمنية)
    const isHeader = line.includes('Asia/Riyadh') || line.includes('|') || line.includes('--') || /\d{2}\/\d{2}\/\d{2}/.test(line) || line.includes('Contractor');
    
    if (isHeader) {
      if (latestLines.length > 0) {
        // إذا كنا قد جمعنا أسطر التحديث الأول ووصلنا للترويسة التالية، نتوقف هنا
        break;
      }
      continue;
    }
    latestLines.push(line);
  }
  
  return latestLines.join('\n').trim();
}

function getTicketNumber() {
  const titleMatch = document.title.match(/IM\d{5,10}/);
  if (titleMatch) return titleMatch[0];

  const inputs = Array.from(document.querySelectorAll('input'));
  for (const input of inputs) {
    const val = (input.value || '').trim();
    const match = val.match(/^IM\d{5,10}$/);
    if (match) return match[0];
  }

  const match = document.body.innerText.match(/IM\d{5,10}/);
  if (match) return match[0];

  return '';
}

function getClassification() {
  // 1. البحث عن خلية تحتوي على نص "التصنيف" والتقاط حقل الإدخال في الخلية المجاورة (سواء السابقة أو التالية)
  const cells = Array.from(document.querySelectorAll('td, label, span'));
  for (const cell of cells) {
    const txt = (cell.innerText || '').trim();
    if (txt === 'التصنيف:' || txt === 'التصنيف' || txt === 'Category:' || txt === 'Category') {
      let cellTd = cell;
      while (cellTd && cellTd.tagName !== 'TD' && cellTd !== document.body) {
        cellTd = cellTd.parentElement;
      }
      
      if (cellTd && cellTd.tagName === 'TD') {
        let input = null;
        
        // تفقد الخلية السابقة (تخطيط RTL المعتاد)
        const prevTd = cellTd.previousElementSibling;
        if (prevTd) {
          input = prevTd.querySelector('input[type="text"], select');
        }
        
        // تفقد الخلية التالية (في حال كان التخطيط LTR أو معكوساً برمجياً)
        if (!input) {
          const nextTd = cellTd.nextElementSibling;
          if (nextTd) {
            input = nextTd.querySelector('input[type="text"], select');
          }
        }
        
        if (input && input.value && input.value.trim() !== '') {
          const val = input.value.trim();
          if (val.toLowerCase() !== 'incident') {
            return val;
          }
        }
      }
    }
  }

  // 2. البحث البديل: إعطاء الأولوية لـ subcategory أو product.type (لأنها تعني التصنيف الفعلي)
  const inputs = Array.from(document.querySelectorAll('input[type="text"]'));
  for (const input of inputs) {
    const name = (input.name || '').toLowerCase();
    const id = (input.id || '').toLowerCase();
    if (
      (name.includes('subcategory') || id.includes('subcategory') || name.includes('product') || id.includes('product')) && 
      !name.includes('group') && !id.includes('group')
    ) {
      if (input.value && input.value.trim() !== '') {
        return input.value.trim();
      }
    }
  }

  // 3. كخيار أخير: حقل category بشرط ألا تكون قيمته incident أو group
  for (const input of inputs) {
    const name = (input.name || '').toLowerCase();
    const id = (input.id || '').toLowerCase();
    if (
      (name.includes('category') || id.includes('category')) && 
      !name.includes('group') && !id.includes('group') && 
      !name.includes('type') && !id.includes('type')
    ) {
      const val = (input.value || '').trim();
      if (val !== '' && val.toLowerCase() !== 'incident') {
        return val;
      }
    }
  }
  return '';
}

function normalizeCategory(rawCategory) {
  if (!rawCategory) return "أخرى";
  
  const cleanCategories = [
    "الرخص التجارية", "الرخص الإنشائية", "بلدي أعمال", "مسار منصة الحفريات", 
    "التقرير المساحي", "الإدارة الذكية للنظافة", "خدمة المواعيد الالكترونية", 
    "الشهادات الصحية", "خدمة مرافق إيواء", "مستشارك بلدي", "نظام الصلاحيات", 
    "تطبيق بلدي", "شكوى المستفيد منصة بلدي", "منصة الرقابة الموحدة (ممثل)", 
    "لوحة التحكم", "خدمة الدمج والتجزئة", "خدمة تحديث الصكوك", 
    "خدمة اعتماد المخططات الخاصة", "تصنيف مقدمي خدمات المدن", "الهوية العقارية", 
    "شكوى المستفيد بلدي 940", "خدمة الفرص الاستثمارية", "خدمة السكن الجماعي", 
    "خدمة السكن الجماعي للأفراد", "صفحة بلدي", "GIS Web Portal", "رمز الاستجابة", 
    "إكرام الموتى", "التشوه البصري", "امتثال", "رقابة الصحي والأسواق", 
    "الخرائط الجغرافية", "صوت العميل", "نظام المتاجر المتنقلة", 
    "شؤون البلدية والقروية والإسكان", "Investment Opportunities", 
    "امتثال المباني", "منصة رسم تقديم منتجات التبغ", "فاتورة سداد آلياً"
  ];

  // 1. مطابقة مباشرة جزئية
  const matched = cleanCategories.find(cat => 
    rawCategory.includes(cat) || cat.includes(rawCategory)
  );
  if (matched) return matched;

  // 2. مطابقة مرنة للكلمات الدلالية الرئيسية
  const lowerRaw = rawCategory.toLowerCase();
  
  if (lowerRaw.includes('digging') || lowerRaw.includes('حفريات')) return 'مسار منصة الحفريات';
  if (lowerRaw.includes('commercial') || lowerRaw.includes('تجارية')) return 'الرخص التجارية';
  if (lowerRaw.includes('building') || lowerRaw.includes('إنشائية')) return 'الرخص الإنشائية';
  if (lowerRaw.includes('survey') || lowerRaw.includes('مساحي')) return 'التقرير المساحي';
  if (lowerRaw.includes('business') || lowerRaw.includes('أعمال')) return 'بلدي أعمال';
  if (lowerRaw.includes('complaint') || lowerRaw.includes('شكوى')) {
    if (lowerRaw.includes('940')) return 'شكوى المستفيد بلدي 940';
    return 'شكوى المستفيد منصة بلدي';
  }
  if (lowerRaw.includes('hygiene') || lowerRaw.includes('صحي') || lowerRaw.includes('أسواق')) return 'رقابة الصحي والأسواق';
  if (lowerRaw.includes('clean') || lowerRaw.includes('نظافة')) return 'الإدارة الذكية للنظافة';
  if (lowerRaw.includes('health') || lowerRaw.includes('شهادة صحية') || lowerRaw.includes('شهادات صحية')) return 'الشهادات الصحية';
  if (lowerRaw.includes('appointment') || lowerRaw.includes('مواعيد')) return 'خدمة المواعيد الالكترونية';
  if (lowerRaw.includes('investment') || lowerRaw.includes('استثمار')) return 'خدمة الفرص الاستثمارية';
  if (lowerRaw.includes('housing') || lowerRaw.includes('سكن جماعي')) return 'خدمة السكن الجماعي';
  
  return "أخرى";
}

// حساب الموظف الذي عليه الدور حسب نفس خوارزمية التوزيع باللوحة الرئيسية
function getLeastReceiver() {
  const priorityOrder = [
    { name: 'البراء النصيان', user: 'a.alnesayan' },
    { name: 'محمد الربيش', user: 'mialrubaish' },
    { name: 'عبدالرحمن العمري', user: 'af.alamri' },
    { name: 'عزام الحربي', user: 'azz.alharbi' },
    { name: 'صالح الغصن', user: 's.alghosen' },
    { name: 'طارق الهدياني', user: 't.alhedyani' },
    { name: 'ثامر المنصور', user: 't.almansour' }
  ];

  const counts = {};
  priorityOrder.forEach(emp => {
    counts[emp.name] = 0;
  });

  const baseTickets = websiteTickets.filter(t => 
    t.date && 
    t.date >= '2026-04-04' && 
    t.type !== 'تحديث نظام' && 
    t.type !== 'تحديثات النظام' &&
    !(t.number && t.number.includes('📢'))
  );

  baseTickets.forEach(t => {
    const receiver = (t.receiver || '').trim();
    if (!receiver || receiver === 'غير محدد') return;

    const matched = priorityOrder.find(p => 
      receiver.includes(p.name.split(' ')[0]) || 
      p.name.includes(receiver.split(' ')[0])
    );

    if (matched) {
      counts[matched.name]++;
    }
  });

  let bestCandidate = priorityOrder[0];
  let minCount = counts[bestCandidate.name];

  for (const emp of priorityOrder) {
    if (counts[emp.name] < minCount) {
      minCount = counts[emp.name];
      bestCandidate = emp;
    }
  }

  return bestCandidate;
}

// إدراج نص ولصقه وتنبيه المستخدم
function insertTextToField(text) {
  const activeInput = findActiveInput();
  if (activeInput) {
    activeInput.value = text;
    activeInput.dispatchEvent(new Event('input', { bubbles: true }));
    activeInput.dispatchEvent(new Event('change', { bubbles: true }));
    activeInput.focus();
    showFloatingNotification("تم نسخ النص ولصقه بنجاح! ⚡");
  } else {
    navigator.clipboard.writeText(text).catch(() => {});
    showFloatingNotification("تعذر اللصق التلقائي؛ تم نسخ النص للحافظة! 📋");
  }
}

function showFloatingNotification(msg) {
  const toast = document.createElement('div');
  toast.style.position = 'fixed';
  toast.style.bottom = '100px';
  toast.style.right = '30px';
  toast.style.backgroundColor = '#10b981';
  toast.style.color = '#fff';
  toast.style.padding = '12px 20px';
  toast.style.borderRadius = '10px';
  toast.style.fontFamily = 'Cairo, sans-serif';
  toast.style.fontSize = '14px';
  toast.style.fontWeight = 'bold';
  toast.style.boxShadow = '0 10px 25px rgba(16,185,129,0.3)';
  toast.style.zIndex = '999999';
  toast.style.direction = 'rtl';
  toast.style.transition = 'all 0.3s ease';
  toast.innerText = msg;
  
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}

// إنشاء وحقن لوحة التحكم العائمة في الصفحة
function injectFloatingPanel() {
  try {
    if (!chrome.runtime || !chrome.runtime.id) return;
  } catch (e) {
    return;
  }

  // تجنب تكرار حقن اللوحة في النافذة الرئيسية (Parent) إذا كان هناك إطار داخلي (Iframe) يحتوي على تفاصيل البلاغ
  if (window === window.top && document.querySelector('iframe')) {
    const existingPanel = document.getElementById('daem-premium-panel');
    if (existingPanel) {
      existingPanel.remove();
    }
    return;
  }

  // نتأكد من أننا في الصفحة التفصيلية للتذكرة (وليس قائمة البحث أو الصفحات الأخرى)
  const ticketId = getTicketNumber();
  const existingPanel = document.getElementById('daem-premium-panel');
  
  if (!ticketId) {
    if (existingPanel) {
      existingPanel.remove();
    }
    return;
  }

  if (existingPanel) {
    const savedId = existingPanel.getAttribute('data-ticket-id');
    if (savedId === ticketId) {
      return;
    } else {
      existingPanel.remove();
    }
  }

  const panel = document.createElement('div');
  panel.id = 'daem-premium-panel';
  panel.setAttribute('data-ticket-id', ticketId);
  panel.style.position = 'fixed';
  panel.style.bottom = '30px';
  panel.style.right = '30px';
  panel.style.width = '300px';
  panel.style.backgroundColor = '#0f172a';
  panel.style.border = '2px solid #10b981';
  panel.style.borderRadius = '16px';
  panel.style.boxShadow = '0 15px 35px rgba(0,0,0,0.5)';
  panel.style.zIndex = '999998';
  panel.style.fontFamily = 'Cairo, Arial, sans-serif';
  panel.style.direction = 'rtl';
  panel.style.overflow = 'hidden';
  panel.style.transition = 'width 0.3s ease, height 0.3s ease, background-color 0.3s ease';

  // حساب الموظف الذي عليه الدور تلقائياً ومواءمة نص الزر
  const nextEmployee = getLeastReceiver();
  const isRobaish = nextEmployee && (nextEmployee.name.includes('محمد الربيش') || nextEmployee.name.includes('الربيش'));
  const dynamicBtnText = isRobaish ? '🔗 إسناد البلاغ تلقائياً لـ Notion والترتيب' : '🔗 إسناد البلاغ تلقائياً لـ Supabase والترتيب';

  // قالب واجهة المستخدم
  panel.innerHTML = `
    <div style="background: linear-gradient(135deg, #10b981, #059669); padding: 12px; display: flex; align-items: center; justify-content: space-between; color: white; cursor: pointer; user-select: none;" id="daem-panel-header">
      <span style="font-weight: bold; font-size: 14px; display: flex; align-items: center; gap: 8px; pointer-events: none;">
        🚀 داعم بلس Premium
      </span>
      <span id="daem-panel-toggle" style="font-size: 16px; font-weight: bold;">−</span>
    </div>
    
    <div id="daem-panel-body" style="padding: 15px; display: flex; flex-direction: column; gap: 10px; transition: all 0.3s ease;">
      <!-- مفتاح التبديل للجهة المستهدفة -->
      <div style="display: flex; background-color: #1e293b; border-radius: 8px; padding: 3px; border: 1px solid #334155;">
        <button id="target-beneficiary" style="flex: 1; background-color: #10b981; color: white; border: none; padding: 6px; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 11px; transition: all 0.2s;">
          👤 المستفيد
        </button>
        <button id="target-office" style="flex: 1; background: transparent; color: #94a3b8; border: none; padding: 6px; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 11px; transition: all 0.2s;">
          🏢 المكتب الهندسي
        </button>
      </div>

      <!-- زر دمج آخر تحديث -->
      <button id="btn-copy-latest" style="background-color: #1e293b; color: #f8fafc; border: 1px solid #334155; padding: 10px; border-radius: 8px; font-weight: bold; cursor: pointer; text-align: right; display: flex; align-items: center; gap: 8px; transition: all 0.2s ease; font-size: 12px;">
        📋 دمج وتحديث البلاغ
      </button>
      <!-- زر إغلاق لعدم الرد -->
      <button id="btn-close-no-reply" style="background-color: #1e293b; color: #f8fafc; border: 1px solid #334155; padding: 10px; border-radius: 8px; font-weight: bold; cursor: pointer; text-align: right; display: flex; align-items: center; gap: 8px; transition: all 0.2s ease; font-size: 12px;">
        ❌ إغلاق لعدم الرد
      </button>

      <!-- زر تمت المعالجة -->
      <button id="btn-solved-feedback" style="background-color: #1e293b; color: #f8fafc; border: 1px solid #334155; padding: 10px; border-radius: 8px; font-weight: bold; cursor: pointer; text-align: right; display: flex; align-items: center; gap: 8px; transition: all 0.2s ease; font-size: 12px;">
        ✅ تمت المعالجة بالإفادة
      </button>

      <!-- زر تصحيح الإملاء -->
      <button id="btn-correct-spelling" style="background-color: #7c3aed; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: bold; cursor: pointer; text-align: right; display: flex; align-items: center; gap: 8px; transition: all 0.2s ease; font-size: 12px;">
        ✨ تصحيح النص إملائياً
      </button>

      <!-- زر نسخ البيانات لإنشاء بلاغ جديد -->
      <button id="btn-copy-new-ticket" style="background-color: #06b6d4; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: bold; cursor: pointer; text-align: right; display: flex; align-items: center; gap: 8px; transition: all 0.2s ease; font-size: 12px;">
        ${dynamicBtnText}
      </button>

      <!-- زر اختياري لتعبئة البيانات المنسوخة (يظهر فقط إذا كان هناك بيانات مخزنة) -->
      <button id="btn-fill-copied" style="background-color: #f59e0b; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: bold; cursor: pointer; text-align: right; display: none; align-items: center; gap: 8px; transition: all 0.2s ease; font-size: 12px;">
        📥 تعبئة وإسناد البلاغ المنسوخ
      </button>
    </div>
  `;

  document.body.appendChild(panel);

  const isDashboard = window.location.href.includes('tickets-daem.vercel.app') || 
                      window.location.href.includes('localhost');
  const btnCopy = document.getElementById('btn-copy-new-ticket');
  if (isDashboard && btnCopy) {
    btnCopy.style.display = 'none';
  }

  // أنماط تحسين تفاعل الأزرار
  const style = document.createElement('style');
  style.innerHTML = `
    #daem-premium-panel button:hover {
      filter: brightness(1.15) !important;
      transform: translateY(-1px) !important;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2) !important;
    }
    #daem-premium-panel button:active {
      transform: translateY(0px) !important;
    }
  `;
  document.head.appendChild(style);

  // إدارة حالة الجهة المستهدفة بالتبديل
  let targetType = 'beneficiary'; // beneficiary or office
  
  const btnBeneficiary = document.getElementById('target-beneficiary');
  const btnOffice = document.getElementById('target-office');

  chrome.storage.local.get(['daemTargetType'], (result) => {
    if (result.daemTargetType) {
      targetType = result.daemTargetType;
      updateTargetUI();
    }
  });

  function updateTargetUI() {
    if (targetType === 'beneficiary') {
      btnBeneficiary.style.backgroundColor = '#10b981';
      btnBeneficiary.style.color = 'white';
      btnOffice.style.backgroundColor = 'transparent';
      btnOffice.style.color = '#94a3b8';
    } else {
      btnOffice.style.backgroundColor = '#10b981';
      btnOffice.style.color = 'white';
      btnBeneficiary.style.backgroundColor = 'transparent';
      btnBeneficiary.style.color = '#94a3b8';
    }
  }

  btnBeneficiary.addEventListener('click', () => {
    targetType = 'beneficiary';
    chrome.storage.local.set({ daemTargetType: 'beneficiary' });
    updateTargetUI();
  });

  btnOffice.addEventListener('click', () => {
    targetType = 'office';
    chrome.storage.local.set({ daemTargetType: 'office' });
    updateTargetUI();
  });

  // منطق تصغير وتكبير اللوحة وسحبها
  const header = document.getElementById('daem-panel-header');
  const body = document.getElementById('daem-panel-body');
  const toggleBtn = document.getElementById('daem-panel-toggle');
  
  let isCollapsed = false;
  let isDragging = false;
  let hasMoved = false;
  let currentX;
  let currentY;
  let initialX;
  let initialY;
  let xOffset = 0;
  let yOffset = 0;

  // استرجاع موضع اللوحة المحفوظ مع التحقق من الحدود لمنع خروجها عن الشاشة
  chrome.storage.local.get(['panelPosition'], (result) => {
    if (result.panelPosition) {
      let savedX = result.panelPosition.x; // left
      let savedY = result.panelPosition.y; // top
      
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      
      const panelWidth = 300;
      const panelHeight = isCollapsed ? 45 : 350;
      
      // التأكد من بقاء الموضع داخل حدود الشاشة المرئية تماماً
      let x = Math.max(10, Math.min(savedX, viewportWidth - panelWidth - 10));
      let y = Math.max(10, Math.min(savedY, viewportHeight - panelHeight - 10));
      
      panel.style.bottom = 'auto';
      panel.style.right = 'auto';
      panel.style.left = x + 'px';
      panel.style.top = y + 'px';
    }
  });

  header.addEventListener('mousedown', dragStart);
  document.addEventListener('mouseup', dragEnd);
  document.addEventListener('mousemove', drag);

  function dragStart(e) {
    if (e.target.id === 'daem-panel-toggle') return;
    
    const rect = panel.getBoundingClientRect();
    initialX = e.clientX - rect.left;
    initialY = e.clientY - rect.top;
    
    isDragging = true;
    hasMoved = false;
  }

  function dragEnd(e) {
    if (!isDragging) return;
    isDragging = false;
    
    const rect = panel.getBoundingClientRect();
    chrome.storage.local.set({ panelPosition: { x: rect.left, y: rect.top } });
  }

  function drag(e) {
    if (!isDragging) return;
    e.preventDefault();
    
    let x = e.clientX - initialX;
    let y = e.clientY - initialY;
    
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const panelWidth = panel.offsetWidth || 300;
    const panelHeight = panel.offsetHeight || 350;
    
    // تقييد الحركة داخل أبعاد الشاشة لمنع الخروج نهائياً
    x = Math.max(10, Math.min(x, viewportWidth - panelWidth - 10));
    y = Math.max(10, Math.min(y, viewportHeight - panelHeight - 10));
    
    panel.style.bottom = 'auto';
    panel.style.right = 'auto';
    panel.style.left = x + 'px';
    panel.style.top = y + 'px';
    
    hasMoved = true;
  }

  function setTranslate(xPos, yPos, el) {
    el.style.transform = `translate3d(${xPos}px, ${yPos}px, 0)`;
  }

  header.addEventListener('click', (e) => {
    // إذا تحركت اللوحة (حدث سحب)، نمنع تكبير/تصغير اللوحة
    if (hasMoved) {
      hasMoved = false;
      return;
    }
    isCollapsed = !isCollapsed;
    if (isCollapsed) {
      body.style.display = 'none';
      panel.style.width = '180px';
      toggleBtn.innerText = '+';
    } else {
      body.style.display = 'flex';
      panel.style.width = '300px';
      toggleBtn.innerText = '−';
    }
  });

  // حدث: دمج آخر تحديث
  document.getElementById('btn-copy-latest').addEventListener('click', () => {
    const journalEl = findJournalUpdatesElement();
    if (!journalEl) {
      showFloatingNotification("لم يتم العثور على صندوق التحديثات بالصفحة! ⚠️");
      return;
    }
    const rawText = journalEl.value || '';
    const lastUpdateText = extractLatestUpdate(rawText);
    
    if (!lastUpdateText) {
      showFloatingNotification("لا توجد تحديثات سابقة لنسخها! ⚠️");
      return;
    }

    const suffix = targetType === 'beneficiary' ? 'المستفيد' : 'المكتب الهندسي';
    const formatted = `${lastUpdateText}\nوإفادة ${suffix} بذلك`;
    insertTextToField(formatted);
  });

  // حدث: إغلاق لعدم الرد
  document.getElementById('btn-close-no-reply').addEventListener('click', () => {
    const suffix = targetType === 'beneficiary' ? 'المستفيد' : 'المكتب الهندسي';
    insertTextToField(`لم يتم الرد من قبل ${suffix}`);
  });

  // حدث: تمت المعالجة بالإفادة
  document.getElementById('btn-solved-feedback').addEventListener('click', () => {
    const suffix = targetType === 'beneficiary' ? 'المستفيد' : 'المكتب الهندسي';
    insertTextToField(`تمت المعالجة بناءً على إفادة ${suffix}`);
  });


  // حدث: نسخ البيانات وإنشاء البلاغ في الموقع تلقائياً في الخلفية
  document.getElementById('btn-copy-new-ticket').addEventListener('click', () => {
    const ticketId = getTicketNumber();
    const category = getClassification() || "أخرى";

    if (!ticketId) {
      showFloatingNotification("فشل تحديد رقم التذكرة بالصفحة! ⚠️");
      return;
    }

    // حساب الموظف الذي عليه الدور تلقائياً
    const nextEmployee = getLeastReceiver();

    // نسخ النص للحافظة كدعم للمستخدم
    const clipboardText = `رقم التذكرة: ${ticketId}\nالتصنيف: ${category}\nالموظف المستلم: ${nextEmployee.name} (${nextEmployee.user})`;
    navigator.clipboard.writeText(clipboardText).catch(() => {});

    // تنسيق التاريخ بتوقيت الرياض YYYY-MM-DD
    const localDate = new Date();
    const offset = 3 * 60; // UTC+3
    const localTime = new Date(localDate.getTime() + (localDate.getTimezoneOffset() + offset) * 60000);
    const dateStr = localTime.toISOString().split('T')[0];

    showFloatingNotification("جاري حفظ البلاغ الجديد وتوزيعه بالدور... ⏳");

    chrome.storage.local.get(['daemRole'], (result) => {
      const role = result.daemRole || 'support';
      const phoneNumber = extractPhone();
      const reportText = extractReportText();

      const apiData = {
        date: dateStr,
        receiver: nextEmployee.name,
        ticketNumber: ticketId,
        type: normalizeCategory(category),
        solution: 'بلاغ جديد',
        phoneNumber: phoneNumber,
        reportText: reportText,
        role: role
      };

      // إرسال الطلب للخلفية لحفظ البلاغ في قاعدة بيانات الموقع مباشرة دون فتح أي نافذة
      chrome.runtime.sendMessage({ action: "CREATE_TICKET", data: apiData }, (response) => {
        if (chrome.runtime.lastError) {
          showFloatingNotification("خطأ في الاتصال بالخدمة الخلفية! ⚠️");
          return;
        }
        if (response && response.success) {
          showFloatingNotification(`تم حفظ البلاغ (${ticketId}) وإسناده للموظف (${nextEmployee.name}) بنجاح! 🚀`);
        } else {
          showFloatingNotification(`فشل حفظ البلاغ تلقائياً: ${response?.error || 'خطأ غير معروف'} ⚠️`);
        }
      });
    });
  });

  // حدث: تصحيح النص إملائياً
  document.getElementById('btn-correct-spelling').addEventListener('click', () => {
    const activeInput = findActiveInput();
    if (!activeInput) {
      showFloatingNotification("لم يتم العثور على حقل كتابة نشط لتصحيحه! ⚠️");
      return;
    }
    const currentText = getEditableValue(activeInput).trim();
    if (!currentText) {
      showFloatingNotification("الرجاء كتابة نص أولاً في حقل الكتابة لتصحيحه! ⚠️");
      return;
    }

    showFloatingNotification("جاري تصحيح النص بالذكاء الاصطناعي... 🪄");

    chrome.runtime.sendMessage({
      action: "CORRECT_SPELLING",
      data: { text: currentText }
    }, (response) => {
      if (response && response.success) {
        const corrected = response.correctedText;
        if (corrected === currentText) {
          showFloatingNotification("لم يتم العثور على أي أخطاء إملائية؛ النص سليم! ✅");
        } else {
          // عرض نافذة تأكيد للمراجعة قبل الاستبدال
          showCorrectionConfirmationModal(currentText, corrected, activeInput);
        }
      } else {
        showFloatingNotification(`فشل تصحيح النص: ${response?.error || 'خطأ غير معروف'} ⚠️`);
      }
    });
  });

  // تفقد صلاحية المستخدم لإخفاء أو إظهار أزرار الإسناد التلقائي وإنشاء البلاغات
  chrome.storage.local.get(['daemRole'], (result) => {
    const role = result.daemRole || 'support';
    const btnCopy = document.getElementById('btn-copy-new-ticket');
    const btnFill = document.getElementById('btn-fill-copied');
    const isDashboard = window.location.href.includes('tickets-daem.vercel.app') || 
                        window.location.href.includes('localhost');

    if (role === 'admin') {
      if (btnCopy && !isDashboard) btnCopy.style.display = 'flex';
      checkCopiedTicketData();
    } else {
      if (btnCopy) btnCopy.style.display = 'none';
      if (btnFill) btnFill.style.display = 'none';
    }
  });
}

function checkCopiedTicketData() {
  const isDashboard = window.location.href.includes('tickets-daem.vercel.app') || 
                      window.location.href.includes('localhost');
  const btn = document.getElementById('btn-fill-copied');
  
  if (!isDashboard) {
    if (btn) btn.style.display = 'none';
    return;
  }

  chrome.storage.local.get(['copiedTicketInfo', 'daemRole'], (result) => {
    const role = result.daemRole || 'support';
    if (role === 'support') {
      if (btn) btn.style.display = 'none';
      return;
    }

    if (result.copiedTicketInfo && btn) {
      const data = result.copiedTicketInfo;
      const oneHour = 60 * 60 * 1000;
      if (Date.now() - data.timestamp < oneHour) {
        btn.style.display = 'flex';
        btn.innerText = `📥 تعبئة وإسناد (${data.ticketId} ➔ ${data.nextEmployee.name.split(' ')[0]})`;
        
        const newBtn = btn.cloneNode(true);
        btn.replaceWith(newBtn);
        newBtn.addEventListener('click', () => {
          fillTicketDataToForm(data);
        });
      }
    }
  });
}

// مراقبة تغيير الصلاحية لتحديث الأزرار حياً في التبويبات النشطة
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.daemRole) {
    const role = changes.daemRole.newValue || 'support';
    const btnCopy = document.getElementById('btn-copy-new-ticket');
    const btnFill = document.getElementById('btn-fill-copied');
    if (role === 'support') {
      if (btnCopy) btnCopy.style.display = 'none';
      if (btnFill) btnFill.style.display = 'none';
    } else {
      const isDashboard = window.location.href.includes('tickets-daem.vercel.app') || 
                          window.location.href.includes('localhost');
      if (btnCopy && !isDashboard) btnCopy.style.display = 'flex';
      checkCopiedTicketData();
    }
  }
});

function fillTicketDataToForm(data) {
  let filledAny = false;

  // 1. تعبئة حقل التصنيف
  const inputs = Array.from(document.querySelectorAll('input[type="text"], textarea'));
  for (const input of inputs) {
    const name = (input.name || '').toLowerCase();
    const id = (input.id || '').toLowerCase();
    if (name.includes('category') || name.includes('class') || id.includes('category') || id.includes('class')) {
      input.value = data.category;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      filledAny = true;
    }
  }

  // 2. تعبئة حقل "المستقبل" أو "التعيين" باسم الموظف الذي عليه الدور
  const assigneeInput = findAssigneeInput();
  if (assigneeInput) {
    assigneeInput.value = data.nextEmployee.user; // استخدام اسم المستخدم (a.alnesayan, mialrubaish, إلخ)
    assigneeInput.dispatchEvent(new Event('input', { bubbles: true }));
    assigneeInput.dispatchEvent(new Event('change', { bubbles: true }));
    filledAny = true;
  }

  // 3. تعبئة تفاصيل/رقم البلاغ القديم في حقل الوصف/الحديثة
  const descriptionField = findActiveInput();
  if (descriptionField) {
    descriptionField.value = `بلاغ مرتبط بالبلاغ رقم: ${data.ticketId}\nالتصنيف: ${data.category}\nمسند إلى: ${data.nextEmployee.name}`;
    descriptionField.dispatchEvent(new Event('input', { bubbles: true }));
    descriptionField.dispatchEvent(new Event('change', { bubbles: true }));
    filledAny = true;
  }

  if (filledAny) {
    showFloatingNotification(`تمت تعبئة البيانات وإسنادها للموظف (${data.nextEmployee.name}) بنجاح! 📥`);
  } else {
    navigator.clipboard.writeText(`رقم البلاغ السابق: ${data.ticketId}\nالتصنيف: ${data.category}\nالمستلم: ${data.nextEmployee.name} (${data.nextEmployee.user})`).then(() => {
      showFloatingNotification("تعذر التحديد التلقائي للحقول. تم نسخ البيانات لتلصقها يدوياً! 📋");
    });
  }
}

// تشغيل الحقن والمراقبة
syncFromWebsite();
setInterval(syncFromWebsite, 60000);
setInterval(highlightTickets, 2000);


// محاولة الحقن فوراً وبشكل دوري لدعم التحديثات الديناميكية (AJAX/iFrames)
setTimeout(injectFloatingPanel, 1500);
setInterval(injectFloatingPanel, 3000);

let daemAutoFilled = false;
function autoFillOnWebsiteNewPage() {
  try {
    if (!chrome.runtime || !chrome.runtime.id) return;
  } catch (e) {
    return;
  }
  if (daemAutoFilled) return;
  
  const isTargetPage = window.location.href.includes('tickets-daem.vercel.app/new') || 
                       window.location.href.includes('tickets-daem.vercel.app/create') ||
                       window.location.href.includes('localhost:3000/new') ||
                       window.location.href.includes('localhost:3000/create');
                       
  if (isTargetPage) {
    const ticketInput = document.getElementById('ticketNumber');
    if (!ticketInput) return; // النموذج لم يتم تحميله بعد في الصفحة
    
    chrome.storage.local.get(['copiedTicketInfo'], (result) => {
      if (result.copiedTicketInfo) {
        const data = result.copiedTicketInfo;
        const fiveMinutes = 5 * 60 * 1000;
        
        // التحقق من أن البيانات حديثة (خلال آخر 5 دقائق) لتجنب تكرار التعبئة
        if (Date.now() - data.timestamp < fiveMinutes) {
          daemAutoFilled = true;
          
          // 1. رقم البلاغ
          ticketInput.value = data.ticketId;
          ticketInput.dispatchEvent(new Event('input', { bubbles: true }));
          ticketInput.dispatchEvent(new Event('change', { bubbles: true }));

          // 2. المستقبل (الموظف)
          const nameInput = document.getElementById('name');
          if (nameInput) {
            const options = Array.from(nameInput.options);
            const matchedOpt = options.find(opt => 
              opt.text.includes(data.nextEmployee.name) || 
              data.nextEmployee.name.includes(opt.text)
            );
            if (matchedOpt) {
              nameInput.value = matchedOpt.value;
              nameInput.dispatchEvent(new Event('change', { bubbles: true }));
            }
          }

          // 3. التصنيف (Custom Select)
          const categoryLabel = document.querySelector('label[htmlFor="serviceType"]');
          if (categoryLabel && data.category) {
            const wrapper = categoryLabel.parentElement.querySelector('[class*="customSelectWrapper"]');
            if (wrapper) {
              const trigger = wrapper.querySelector('[class*="customSelectTrigger"]');
              if (trigger) {
                trigger.click();
                setTimeout(() => {
                  const options = Array.from(wrapper.querySelectorAll('[class*="customOption"]'));
                  const matchedOption = options.find(opt => {
                    const optText = opt.innerText.trim();
                    return optText.includes(data.category) || data.category.includes(optText);
                  });
                  if (matchedOption) {
                    matchedOption.click();
                  } else {
                    const otherOpt = options.find(opt => opt.innerText.includes('أخرى'));
                    if (otherOpt) otherOpt.click();
                  }
                }, 200);
              }
            }
          }

          // 4. الحفظ التلقائي بعد وقت كافٍ لاكتمال تعبئة الحقول والخيارات
          setTimeout(() => {
            const submitBtn = document.querySelector('button[type="submit"]');
            if (submitBtn) {
              submitBtn.click();
            }
          }, 800);

          chrome.storage.local.remove(['copiedTicketInfo']);
          showFloatingNotification("تمت تعبئة تفاصيل البلاغ وحفظه تلقائياً! ⚡");
        }
      }
    });
  }
}
// تشغيل التعبئة التلقائية عند تحميل الصفحة
setTimeout(autoFillOnWebsiteNewPage, 1000);
setInterval(autoFillOnWebsiteNewPage, 2000);
setInterval(checkAndAutoUpdateMinistryDate, 5000);
setInterval(checkOpenedByEmployee, 3000);
setInterval(checkTicketDescriptionSpelling, 4000);

// ==========================================================
// وظائف استخلاص البيانات والتصحيح الإملائي وتحديث الوزارة
// ==========================================
function queryAllInPage(selector) {
  let elements = Array.from(document.querySelectorAll(selector));
  const iframes = Array.from(document.querySelectorAll('iframe'));
  for (const iframe of iframes) {
    try {
      const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
      if (iframeDoc) {
        elements = elements.concat(Array.from(iframeDoc.querySelectorAll(selector)));
      }
    } catch (e) {
      // ignore cross-origin errors
    }
  }
  return elements;
}

function extractValue(labels) {
  const allElements = queryAllInPage('div, span, label, td, th, p, b, input, textarea');
  for (let el of allElements) {
    const text = el.innerText ? el.innerText.trim() : "";
    const val = el.value ? el.value.trim() : "";
    
    if (labels.some(label => text.includes(label) || val.includes(label))) {
      let foundValue = "";
      if (text.includes(':')) {
        let parts = text.split(':');
        if (parts[1] && parts[1].trim().length > 1) foundValue = parts[1].trim();
      }
      if (!foundValue) {
        let sibling = el.nextElementSibling;
        while (sibling) {
          const input = sibling.querySelector('input, textarea') || (['INPUT', 'TEXTAREA'].includes(sibling.tagName) ? sibling : null);
          if (input && input.value) {
            foundValue = input.value;
            break;
          }
          if (sibling.innerText && sibling.innerText.trim().length > 1) {
            foundValue = sibling.innerText.trim();
            break;
          }
          sibling = sibling.nextElementSibling;
        }
      }
      if (!foundValue && (el.tagName === 'TD' || el.tagName === 'TH' || el.parentElement.tagName === 'TD')) {
        let cell = el.tagName === 'TD' ? el : el.parentElement;
        
        let nextCell = cell.nextElementSibling;
        if (nextCell) {
          const input = nextCell.querySelector('input, textarea');
          foundValue = input ? input.value : nextCell.innerText.trim();
        }

        if (!foundValue) {
          let prevCell = cell.previousElementSibling;
          if (prevCell) {
            const input = prevCell.querySelector('input, textarea');
            foundValue = input ? input.value : prevCell.innerText.trim();
          }
        }
      }
      if (foundValue && foundValue.length > 1) return foundValue;
    }
  }
  return "";
}

function extractPhone() {
  const fromLabel = extractValue(["جوال المواطن", "رقم الجوال", "الهاتف"]);
  if (fromLabel && fromLabel.length >= 9) return fromLabel;

  const bodyText = document.body.innerText;
  const phoneRegex = /(05\d{8}|(?<!\d)5\d{8}(?!\d))/g;
  const matches = bodyText.match(phoneRegex);
  if (matches) {
    return matches[0];
  }
  return "";
}

function extractReportText() {
  const textareas = queryAllInPage('textarea');
  for (let ta of textareas) {
    if (ta.readOnly || ta.disabled) {
      if (ta.value.length > 20) return ta.value;
    }
  }
  for (let ta of textareas) {
    if (ta.value.length > 20 && !ta.value.includes('Asia/Riyadh')) return ta.value;
  }
  return extractValue(["نص البلاغ", "تفاصيل البلاغ", "الوصف"]);
}

function detectMinistryUpdateToday() {
  const journalEl = findJournalUpdatesElement();
  if (!journalEl) return false;
  
  const rawText = journalEl.tagName === 'TEXTAREA' ? (journalEl.value || '') : (journalEl.innerText || '');
  
  const today = new Date();
  const dd = String(today.getDate()).padStart(2, '0');
  const mm = String(today.getMonth() + 1).padStart(2, '0');
  const yyyy = today.getFullYear();
  
  const format1 = `${dd}/${mm}/${yyyy}`;
  const format2 = `${yyyy}-${mm}-${dd}`;
  const format3 = `${yyyy}/${mm}/${dd}`;
  
  const lines = rawText.split('\n');
  for (const line of lines) {
    const hasMinistry = line.includes('الوزارة') || line.includes('وزارة') || line.includes('Ministry');
    const hasToday = line.includes(format1) || line.includes(format2) || line.includes(format3);
    if (hasMinistry && hasToday) {
      return true;
    }
  }
  return false;
}

function checkAndAutoUpdateMinistryDate() {
  chrome.storage.local.get(['daemRole'], (result) => {
    const role = result.daemRole || 'support';
    if (role !== 'admin') return; 
    
    const ticketId = getTicketNumber();
    if (!ticketId) return;
    
    if (!window.daemProcessedMinistryTickets) {
      window.daemProcessedMinistryTickets = {};
    }
    if (window.daemProcessedMinistryTickets[ticketId]) return;
    
    if (detectMinistryUpdateToday()) {
      window.daemProcessedMinistryTickets[ticketId] = true;
      
      const today = new Date();
      const offset = 3 * 60; // UTC+3
      const localTime = new Date(today.getTime() + (today.getTimezoneOffset() + offset) * 60000);
      const todayStr = localTime.toISOString().split('T')[0];
      
      chrome.runtime.sendMessage({
        action: "UPDATE_TICKET_DATE",
        data: {
          ticketNumber: ticketId,
          date: todayStr
        }
      }, (response) => {
        if (response && response.success) {
          showFloatingNotification("تم تحديث تاريخ البلاغ في نوشن تلقائياً! 📅");
        }
      });
    }
  });
}function showCorrectionConfirmationModal(original, corrected, inputElement) {
  const modal = document.createElement('div');
  modal.id = 'daem-spelling-modal';
  modal.style.position = 'fixed';
  modal.style.top = '0';
  modal.style.left = '0';
  modal.style.width = '100vw';
  modal.style.height = '100vh';
  modal.style.backgroundColor = 'rgba(15, 23, 42, 0.75)';
  modal.style.display = 'flex';
  modal.style.alignItems = 'center';
  modal.style.justifyContent = 'center';
  modal.style.zIndex = '9999999';
  modal.style.fontFamily = 'Cairo, sans-serif';
  modal.style.direction = 'rtl';

  modal.innerHTML = `
    <div style="background-color: #1e293b; border: 2px solid #10b981; border-radius: 16px; width: 450px; padding: 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.6); display: flex; flex-direction: column; gap: 15px; color: white;">
      <div style="font-weight: bold; font-size: 16px; color: #10b981; border-bottom: 1px solid #334155; padding-bottom: 10px; display: flex; align-items: center; gap: 8px;">
        🪄 مراجعة وتصحيح النص الإملائي
      </div>
      
      <div>
        <div style="font-size: 11px; color: #94a3b8; margin-bottom: 5px;">النص الأصلي:</div>
        <div style="background-color: #0f172a; padding: 10px; border-radius: 8px; font-size: 12px; border: 1px solid #334155; line-height: 1.5; color: #cbd5e1; max-height: 80px; overflow-y: auto;">
          ${original}
        </div>
      </div>
      
      <div>
        <div style="font-size: 11px; color: #10b981; margin-bottom: 5px;">النص المصحح المقترح:</div>
        <div style="background-color: #0f172a; padding: 10px; border-radius: 8px; font-size: 13px; border: 1px solid #10b981; line-height: 1.5; font-weight: bold; max-height: 120px; overflow-y: auto;">
          ${corrected}
        </div>
      </div>
      
      <div style="display: flex; gap: 10px; margin-top: 10px;">
        <button id="btn-spelling-confirm" style="flex: 2; background-color: #10b981; color: white; border: none; padding: 10px; border-radius: 8px; font-weight: bold; cursor: pointer; font-family: Cairo; font-size: 12px; transition: all 0.2s;">
          ${(inputElement && inputElement.tagName) ? 'استبدال وتحديث الحقل ✏️' : 'نسخ النص المصحح للحافظة 📋'}
        </button>
        <button id="btn-spelling-cancel" style="flex: 1; background-color: #334155; color: #cbd5e1; border: 1px solid #475569; padding: 10px; border-radius: 8px; font-weight: bold; cursor: pointer; font-family: Cairo; font-size: 12px; transition: all 0.2s;">
          إلغاء ❌
        </button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);
  document.getElementById('btn-spelling-confirm').addEventListener('click', () => {
    if (inputElement && inputElement.tagName) {
      setEditableValue(inputElement, corrected);
      inputElement.dispatchEvent(new Event('input', { bubbles: true }));
      inputElement.dispatchEvent(new Event('change', { bubbles: true }));
      inputElement.focus();
      showFloatingNotification("تم استبدال النص وتصحيحه بنجاح! ⚡");
    } else {
      navigator.clipboard.writeText(corrected).then(() => {
        showFloatingNotification("تم نسخ النص المصحح للحافظة بنجاح! 📋");
      }).catch(() => {
        showFloatingNotification("فشل نسخ النص؛ يرجى تحديده ونسخه يدوياً. ⚠️");
      });
    }
    modal.remove();
  });


  document.getElementById('btn-spelling-cancel').addEventListener('click', () => {
    modal.remove();
  });
}

// ==========================================
// فحص وتنبيه البلاغات المرفوعة من قبل موظفينا
// ==========================================

const EMPLOYEE_IDENTIFIERS = [
  'a.alnesayan', 'aalowaid', 'af.alamri', 'azz.alharbi', 'mialrubaish', 's.alghosen', 't.alhedyani', 't.almansour',
  'alnesayan', 'alowaid', 'alamri', 'alharbi', 'mialrubaish', 'alghosen', 'alhedyani', 'almansour',
  'البراء النصيان', 'عبدالله العويد', 'عبدالرحمن العمري', 'عزام الحربي', 'محمد الربيش', 'صالح الغصن', 'طارق الهدياني', 'ثامر المنصور',
  'البراء علي ابراهيم النصيان', 'عبدالله عبدالعزيز محمد العويد', 'عبدالرحمن فهيد العمري', 'عزام أحمد محمد الفريدي الحربي',
  'محمد إبراهيم محمد الربيش', 'صالح عبدالعزيز صالح الغصن', 'طارق عبدالعزيز عبدالله الهدياني', 'ثامر عبدالله محمد المنصور'
];

function extractOpenedByValue() {
  const allElements = queryAllInPage('div, span, label, td, th, p, b, input');
  for (let el of allElements) {
    const text = el.innerText ? el.innerText.trim() : "";
    if (text === 'فتح بواسطة:' || text === 'فتح بواسطة' || text.includes('Opened by') || text.includes('Opened By')) {
      let foundValue = "";
      
      // 1. إذا كان يحتوي على نقطتين وقيمة
      if (text.includes(':')) {
        let parts = text.split(':');
        if (parts[1] && parts[1].trim().length > 1) {
          foundValue = parts[1].trim();
        }
      }
      
      // 2. البحث في الأشقاء التاليين والسابقين
      if (!foundValue) {
        let sibling = el.nextElementSibling;
        while (sibling) {
          const input = sibling.querySelector('input') || (sibling.tagName === 'INPUT' ? sibling : null);
          if (input && input.value) {
            foundValue = input.value;
            break;
          }
          const textVal = sibling.innerText ? sibling.innerText.trim() : "";
          if (textVal && textVal.length > 1 && textVal !== 'i' && textVal !== 'ℹ️' && textVal !== 'ℹ') {
            foundValue = textVal;
            break;
          }
          sibling = sibling.nextElementSibling;
        }
      }

      if (!foundValue) {
        let sibling = el.previousElementSibling;
        while (sibling) {
          const input = sibling.querySelector('input') || (sibling.tagName === 'INPUT' ? sibling : null);
          if (input && input.value) {
            foundValue = input.value;
            break;
          }
          const textVal = sibling.innerText ? sibling.innerText.trim() : "";
          if (textVal && textVal.length > 1 && textVal !== 'i' && textVal !== 'ℹ️' && textVal !== 'ℹ') {
            foundValue = textVal;
            break;
          }
          sibling = sibling.previousElementSibling;
        }
      }
      
      // 3. البحث في الخلية المجاورة
      if (!foundValue && (el.tagName === 'TD' || el.tagName === 'TH' || el.parentElement.tagName === 'TD')) {
        let cell = el.tagName === 'TD' ? el : el.parentElement;
        
        let nextCell = cell.nextElementSibling;
        if (nextCell) {
          const input = nextCell.querySelector('input');
          if (input && input.value) {
            foundValue = input.value;
          } else {
            foundValue = nextCell.innerText ? nextCell.innerText.trim() : "";
          }
        }

        if (!foundValue) {
          let prevCell = cell.previousElementSibling;
          if (prevCell) {
            const input = prevCell.querySelector('input');
            if (input && input.value) {
              foundValue = input.value;
            } else {
              foundValue = prevCell.innerText ? prevCell.innerText.trim() : "";
            }
          }
        }
      }
      
      if (foundValue) {
        foundValue = foundValue.replace(/[iℹ️ℹ]/g, '').trim();
        return foundValue;
      }
    }
  }
  return "";
}

function checkOpenedByEmployee() {
  const openedByRaw = extractOpenedByValue().trim();
  if (!openedByRaw) return;
  const openedBy = openedByRaw.toLowerCase();

  // منع تكرار إظهار التنبيه لنفس البلاغ في نفس الجلسة
  const ticketId = getTicketNumber();
  if (ticketId) {
    if (!window.daemOpenedByAlertedTickets) {
      window.daemOpenedByAlertedTickets = {};
    }
    if (window.daemOpenedByAlertedTickets[ticketId]) return;
  }

  const matches = EMPLOYEE_IDENTIFIERS.some(id => {
    const cleanId = id.trim().toLowerCase();
    return openedBy === cleanId || openedBy.includes(cleanId) || cleanId.includes(openedBy);
  });

  if (matches) {
    if (ticketId) {
      window.daemOpenedByAlertedTickets[ticketId] = true;
    }
    showOpenedByNotification(`⚠️ تنبيه: تم رفع هذا البلاغ من قبل موظفينا (${openedByRaw})!`);
  }
}

function showOpenedByNotification(msg) {
  if (document.getElementById('daem-openedby-alert')) return;

  const alertDiv = document.createElement('div');
  alertDiv.id = 'daem-openedby-alert';
  alertDiv.style.position = 'fixed';
  alertDiv.style.bottom = '100px';
  alertDiv.style.left = '30px';
  alertDiv.style.backgroundColor = '#d97706'; // برتقالي تحذيري مميز
  alertDiv.style.color = '#ffffff';
  alertDiv.style.padding = '14px 24px';
  alertDiv.style.borderRadius = '12px';
  alertDiv.style.fontFamily = 'Cairo, sans-serif';
  alertDiv.style.fontSize = '14px';
  alertDiv.style.fontWeight = 'bold';
  alertDiv.style.boxShadow = '0 10px 30px rgba(217, 119, 6, 0.4)';
  alertDiv.style.zIndex = '999999';
  alertDiv.style.direction = 'rtl';
  alertDiv.style.display = 'flex';
  alertDiv.style.alignItems = 'center';
  alertDiv.style.gap = '10px';
  alertDiv.style.border = '2px solid #f59e0b';
  alertDiv.style.transition = 'all 0.3s ease';

  alertDiv.innerHTML = `
    <span>📢</span>
    <span>${msg}</span>
    <button id="btn-close-openedby-alert" style="background: transparent; border: none; color: white; cursor: pointer; font-weight: bold; margin-right: 15px; font-size: 14px;">✕</button>
  `;

  document.body.appendChild(alertDiv);
  
  document.getElementById('btn-close-openedby-alert').addEventListener('click', () => {
    alertDiv.remove();
  });
}

// ==========================================
// الفحص التلقائي والتنبيه عند وجود أخطاء إملائية بالوصف
// ==========================================

function checkTicketDescriptionSpelling() {
  const ticketId = getTicketNumber();
  if (!ticketId) return;

  if (!window.daemCheckedSpellingTickets) {
    window.daemCheckedSpellingTickets = {};
  }
  if (window.daemCheckedSpellingTickets[ticketId]) return;

  const text = extractReportText();
  if (!text || text.length < 10) return;

  // تحديد أن التذكرة جاري فحصها لمنع التكرار
  window.daemCheckedSpellingTickets[ticketId] = true;

  chrome.runtime.sendMessage({
    action: "CORRECT_SPELLING",
    data: { text: text }
  }, (response) => {
    if (response && response.success && response.errorCount > 0) {
      showSpellingAlert(response.errorCount, text, response.correctedText);
    }
  });
}

function showSpellingAlert(errorCount, originalText, correctedText) {
  if (document.getElementById('daem-spelling-alert')) return;

  const alertDiv = document.createElement('div');
  alertDiv.id = 'daem-spelling-alert';
  alertDiv.style.position = 'fixed';
  alertDiv.style.bottom = '170px'; // موضوعة فوق تنبيه فتح بواسطة لتفادي التداخل
  alertDiv.style.left = '30px';
  alertDiv.style.backgroundColor = '#7c3aed'; // لغز بنفسجي مميز
  alertDiv.style.color = '#ffffff';
  alertDiv.style.padding = '14px 24px';
  alertDiv.style.borderRadius = '12px';
  alertDiv.style.fontFamily = 'Cairo, sans-serif';
  alertDiv.style.fontSize = '14px';
  alertDiv.style.fontWeight = 'bold';
  alertDiv.style.boxShadow = '0 10px 30px rgba(124, 58, 237, 0.4)';
  alertDiv.style.zIndex = '999999';
  alertDiv.style.direction = 'rtl';
  alertDiv.style.display = 'flex';
  alertDiv.style.alignItems = 'center';
  alertDiv.style.gap = '15px';
  alertDiv.style.border = '2px solid #a78bfa';
  alertDiv.style.transition = 'all 0.3s ease';

  alertDiv.innerHTML = `
    <span>🪄</span>
    <span>هل تريد تصحيح الأخطاء الإملائية؟ (تم اكتشاف ${errorCount} كلمة خاطئة في تفاصيل البلاغ)</span>
    <button id="btn-spelling-alert-correct" style="background-color: #10b981; border: none; color: white; padding: 6px 12px; cursor: pointer; font-family: Cairo; font-weight: bold; font-size: 12px; border-radius: 6px;">✏️ تصحيح النص</button>
    <button id="btn-close-spelling-alert" style="background: transparent; border: none; color: white; cursor: pointer; font-weight: bold; font-size: 14px;">✕</button>
  `;

  document.body.appendChild(alertDiv);

  document.getElementById('btn-spelling-alert-correct').addEventListener('click', () => {
    const activeInput = findActiveInput();
    showCorrectionConfirmationModal(originalText, correctedText, activeInput);
    alertDiv.remove();
  });

  document.getElementById('btn-close-spelling-alert').addEventListener('click', () => {
    alertDiv.remove();
  });
}



